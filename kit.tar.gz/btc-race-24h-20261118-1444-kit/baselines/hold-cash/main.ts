// Baseline: hold cash. It never orders: every reply is empty, so its net PnL is 0 on every window, with
// nothing bought, no fee paid and no position to flatten. bars-beat-strategy enters it beside the
// strategies an idea names (server/seeding/templates/bars-beat-strategy), so a prize needs a net PnL
// above holding cash as well as above each strategy: an entry that trades its minimum and otherwise
// sits in cash cannot win on a window where every strategy loses.
//
// Laid out like an entrant's repository: the grader runs `node /bot/main.ts` with this directory
// mounted at /bot; vendor/makefun-bars.ts is a byte-identical copy of bars/sdk/makefun-bars.ts
// (tests/unit/baselines.test.ts keeps it so).

import { runBars } from './vendor/makefun-bars.ts';

await runBars({
  onBatch() {
    return [];
  },
});
